﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missile : MonoBehaviour {
	private float _speedX; //ミサイルの速度

	void Start () {
		Init();
	}

    void Update() {
		//常にミサイルを回転させる
        transform.Rotate(new Vector3(0,0,-25));

		//Position（左から右へ移動を繰り返す）
		if (transform.position.x < 10) {
			Vector3 _missilePos = transform.position;
			_missilePos.x += _speedX;
			transform.position = _missilePos;
		} else {
			Init();
		}
    }

	//ミサイルの初期化（どんな状態でも元に戻す）
	void Init () {
		//Visible（何かタイミングで消えている場合…）
		if (! gameObject.activeSelf) { //非表示の場合
			gameObject.SetActive(true); //表示する
		}

		//Position（位置）
		Vector3 _missilePos = transform.position;
		_missilePos.x = -11;
		_missilePos.y = -0.36f; //UnityEngine.Random.Range(0.5f, 2.3f);
		_missilePos.z = 0;
		transform.position = _missilePos;

		//Rotation（角度）
		transform.rotation = Quaternion.Euler(0.0f, 90.0f, -90.0f);
		transform.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
		transform.GetComponent<Rigidbody>().velocity = Vector3.zero;

		//Speed（速度）
		_speedX = UnityEngine.Random.Range(0.35f, 0.5f);
	}

	void OnCollisionEnter(Collision _target) {
		//gameObject.SetActive(false); //ミサイルを消す場合
		Debug.Log("命中");
	}
}