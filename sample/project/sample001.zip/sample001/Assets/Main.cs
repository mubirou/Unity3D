﻿//Main.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //for Button

public class Main : MonoBehaviour {
	private GameObject _floor;

	void Start () {
		_floor = GameObject.Find("floor");

		//ボタンの色の変更
        GameObject _canvas = GameObject.Find("Canvas");
        foreach (Transform _child in _canvas.transform){
            //IDLEボタンを#FFCC00に変更
            if(_child.name == "Button_Idle"){
                Button _theButton = _child.gameObject.GetComponent<Button>();
                ColorBlock _colors = _theButton.colors;
                _colors.normalColor = new Color(1.0f, 0.8f, 0.0f, 1.0f);
                _theButton.colors = _colors;
            }
        }
	}
	
	void Update () {
		_floor.transform.Rotate(new Vector3(0,1,0));
	}
}
