﻿//===========================================================
// Missileクラス
//===========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missile : MonoBehaviour {
	private BigExplosion _bigExplosion;
	private bool _isBomb = false;
	private bool _isDeath = false;
	private float _speedZ;
	private Mubirou _mubirouScript;
	private JumpButton _jumpButtonScript;
    //カスタムイベント関連
    public delegate void MyDelegate(object arg);
    public event MyDelegate PointEvent;

	//Missile.Start()
	void Start () {
		Init();

		//BigExplosion
		GameObject _theGameObject = GameObject.Find("BigExplosion");
		_bigExplosion = _theGameObject.GetComponent<BigExplosion>();
		_bigExplosion.EndEvent += EndHandler;

		//Mubirou
		_theGameObject = GameObject.Find("mubirou");
		_mubirouScript = _theGameObject.GetComponent<Mubirou>();

		//JumpButton
		_theGameObject = GameObject.Find("JumpButton");
		_jumpButtonScript = _theGameObject.GetComponent<JumpButton>();
	}

	//Missile.EndHandler()
	private void EndHandler (object arg) {
		_isBomb = false;
		Init();
		_jumpButtonScript.Enabled = true;
	}

	/***************************
	Missile.Update()
	***************************/
	void Update () {
		if (!_isBomb) {
			if (!_isDeath) {
				//Rotation
				transform.Rotate(new Vector3(0,0,-25));
				//Position
				if (transform.position.z < 6.8) {
					Vector3 _missilePos = transform.position;
					_missilePos.z += _speedZ;
					transform.position = _missilePos;
				} else {
					Init();
					Debug.Log(PointEvent); //Null????????????
					PointEvent(10); //イベントハンドラの呼出し
				}
			}
		}
	}

	/***************************
	Missile.Init()
	***************************/
	void Init () {
		//Visible
		if (! gameObject.activeSelf) {
			gameObject.SetActive(true);
		}
		//Position
		Vector3 _missilePos = transform.position;
		_missilePos.x = 0;
		_missilePos.y = UnityEngine.Random.Range(0.5f, 2.3f);
		_missilePos.z = -14;
		transform.position = _missilePos;
		//Rotation
		transform.rotation = Quaternion.Euler(0.0f, 0.0f, 0.0f);
		transform.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
		transform.GetComponent<Rigidbody>().velocity = Vector3.zero;
		//Speed
		_speedZ = UnityEngine.Random.Range(0.35f, 0.5f);
	}

	/***************************
	Missile.OnCollisionEnter()
	***************************/
	void OnCollisionEnter(Collision _target) {
		_isBomb = true;
		//Visible
		gameObject.SetActive(false);

		Vector3 _thisPos = transform.position;
		_bigExplosion.Begin(_thisPos.x, _thisPos.y, _thisPos.z);

		_mubirouScript.Death();
		_mubirouScript.ComebackEvent += ComebackHandler;
		_isDeath = true;

		_jumpButtonScript.Enabled = false;
	}

	/***************************
	Missile.ComebackHandler()
	***************************/
	private void ComebackHandler (object arg) {
		_isDeath = false;
	}
}