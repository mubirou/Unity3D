﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missile : MonoBehaviour {
	private bool _isEnabled = true;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public bool Enabled {
        get { return _isEnabled; } //thisは省略
        set { _isEnabled = value; } //thisは省略 ←valueは予め定義された変数
    }

	public void Init() {
		Vector3 _missilePos = this.transform.position;
		_missilePos.x = 0;
		_missilePos.y = UnityEngine.Random.Range(0.5f, 2.3f); //乱数
		//Debug.Log(_missilePos.y);
		_missilePos.z = -14;
		this.transform.position = _missilePos;
		//Rest
		this.transform.rotation = Quaternion.Euler(0.0f, 0.0f, 0.0f);
		this.transform.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
		this.transform.GetComponent<Rigidbody>().velocity = Vector3.zero;
	}
}
