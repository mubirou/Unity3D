﻿//===========================================================
// BigExplosionクラス
//===========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigExplosion : MonoBehaviour {
	private ParticleSystem _particle;
	//for Custom Event
	public delegate void MyDelegate(object arg);
	public event MyDelegate EndEvent;

	void Start () {
		_particle = GetComponent<ParticleSystem>();
		//_particle.gameObject.SetActive(false);
	}

	/***************************
	BigExplosion.Bigin()
	***************************/
	public void Begin (float _x, float _y, float _z) {
		_particle.gameObject.SetActive(true);
		if (! _particle.gameObject.activeSelf) {
			_particle.gameObject.SetActive(true);
		}
		Vector3 _thisPos = transform.position;
		_thisPos.x = _x;
		_thisPos.y = _y;
		_thisPos.z = _z;
		transform.position = _thisPos;
		_particle.Play();
		Invoke("InvokeMethod", _particle.main.duration);
	}

	/***************************
	BigExplosion.Bigin()
	***************************/
	private void InvokeMethod () {
		_particle.Stop();
		_particle.gameObject.SetActive(false);
		if (EndEvent != null) { EndEvent(this); }
		CancelInvoke(); //無駄にInvokeを繰返させないため
	}

	/***************************
	BigExplosion.Visible
	***************************/
	public bool Visible {
		get { return gameObject.activeSelf; }
		set { gameObject.SetActive(value); }
	}
}