﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mubirou : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Debug.Log("Mubirou.Start");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision arg) { //衝突判
		Debug.Log("Mubirou.OnCollisionEnter");
	}

	void OnTriggerEnter(Collider arg) {
		Debug.Log("Mubirou.OnTriggerEnter");
	}
}
