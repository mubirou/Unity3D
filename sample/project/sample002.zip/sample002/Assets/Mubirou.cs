﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mubirou : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//GetComponent<Rigidbody>().useGravity = false;
		Debug.Log("Mubirou.Start");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    //Box Collider -> Is Trigger OFF
    void OnCollisionEnter(Collision collision) {
        Debug.Log("A");
    }

    void OnCollisionExit(Collision collision) {
        Debug.Log("B");
    }
    
    void OnCollisionStay(Collision collision) {
        Debug.Log("C");
    }

    //Box Collider -> Is Trigger ON
    void OnTriggerEnter(Collider collider){
        Debug.Log("D");
    }

    void OnTriggerExit(Collider collider){
        Debug.Log("E");
    }
    
    void OnTriggerStay(Collider collider){    
        Debug.Log("F");
    }
}
