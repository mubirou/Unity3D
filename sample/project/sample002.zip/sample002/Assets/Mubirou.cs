﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mubirou : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//GetComponent<Rigidbody>().useGravity = false;
		Debug.Log("Mubirou_Start");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision arg) { //衝突判定
		Debug.Log("AAA");
	}
}
