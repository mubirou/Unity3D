﻿//===========================================================
// Mubirouクラス
//===========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System; //for Math

public class Mubirou : MonoBehaviour {
    private Animator _mubirouAnim;
    private string _status = "Run";
    private float _count = 0.0f;
    private float _originX;
    private float _originY;
    private float _originZ;
    //private float _currentX;
    private float _currentY;
    //private float _currentZ;
    //カスタムイベント関連
    public delegate void MyDelegate(object arg);
    public event MyDelegate ComebackEvent;
    public event MyDelegate DeathEvent; //NEW
    //得点関連
    private int _addPoint; //加点される場合の点数

    void Start () {
        _mubirouAnim = GetComponent<Animator>();
        _originX = transform.position.x;
        _originY = _currentY = transform.position.y;
        _originZ = transform.position.z;
    }

    void Update () {
        if (_status == "Jump") {
            if (_count < Math.PI) { //0-180d
                _count += 0.25f; //微調整
                float _nextY = (float)(3 * Math.Abs(Math.Sin(_count)) + _originY);
                float _disY = _nextY - _currentY;
                transform.Translate(0, _disY, 0); //移動させたい値（x,y,z）を指定
                _currentY = transform.position.y;
            } else {
                _status = "Run";
                _count = 0f;
                _mubirouAnim.SetBool("isJump", false);
                _mubirouAnim.SetBool("isRun", true);
                Vector3 _thisPos = transform.position;
                _thisPos.x = _originX;
                _thisPos.y = _originY;
                _thisPos.z = _originZ;
                transform.position = _thisPos;
            }
        }
    }

    public void Run () {
        _status = "Run";
        _mubirouAnim.SetBool("isBreak", false);
        _mubirouAnim.SetBool("isDeath", false);
        _mubirouAnim.SetBool("isJump", false);
        _mubirouAnim.SetBool("isRun", true);
    }

    public void Jump () {
        _status = "Jump";
        _mubirouAnim.SetBool("isBreak", false);
        _mubirouAnim.SetBool("isDeath", false);
        _mubirouAnim.SetBool("isJump", true);
        _mubirouAnim.SetBool("isRun", false);

        //Missileとの距離 x 高さ = 加点
        GameObject _missile = GameObject.Find("Missile");
        float _disZ = -(_missile.transform.position.z - transform.position.z);
        float _missileY = _missile.transform.position.y;
        _addPoint = (int)(Math.Round(_missileY * _disZ * 10));
    }

    public void Death () {
        _status = "Death";
        _mubirouAnim.SetBool("isBreak", false);
        _mubirouAnim.SetBool("isDeath", true);
        _mubirouAnim.SetBool("isJump", false);
        _mubirouAnim.SetBool("isRun", false);
        //Position
        Vector3 _thisPos = transform.position;
        _thisPos.x = _originX;
        _thisPos.y = _originY;
        _thisPos.z = _originZ;
        transform.position = _thisPos;

        Invoke("InvokeComeback", 1f); //1.5
        DeathEvent(this);
    }

    private void InvokeComeback () {
        Run();
        ComebackEvent(this); //イベントハンドラの呼出し
    }

    public float Point {
        get { return _addPoint; } //thisは省略
        private set {} //外部からアクセス不可（読み取り専用にする）
    }
}
