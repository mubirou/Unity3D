﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mubirou : MonoBehaviour {
    //for Effect
    private GameObject _bigExplosion;
    private ParticleSystem _particle;
    private GameObject _mubirou;
    private Animator _mubirouAnim;
    private bool _isDath = false;

    private GameObject _missile;
    private Missile _missileClass;

	// Use this for initialization
	void Start () {
		//Debug.Log("Mubirou.Start!");
        _bigExplosion = GameObject.Find("BigExplosion");
        //for Effect
        _bigExplosion = GameObject.Find("BigExplosion");
        _particle =_bigExplosion.GetComponent<ParticleSystem>();
        //_particle.Stop();

        _mubirou = GameObject.Find("mubirou");
        _mubirouAnim = _mubirou.GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
        if (_isDath) {
            if (_mubirouAnim.GetCurrentAnimatorClipInfo(0)[0].clip.name 
            == "アーマチュア|Run") {
                _isDath = false;
                _bigExplosion.SetActive(true);
            }
        }
	}

    //Box Collider -> Is Trigger OFF
    void OnCollisionEnter(Collision arg) {
        //命中した位置
        GameObject _missile = GameObject.Find("missile");
        Vector3 _missilePos = _missile.transform.position;

        //パーティクル再生（爆発）
        Vector3 _thisPos = _bigExplosion.transform.position;
        _thisPos.x = arg.transform.position.x;
        _thisPos.y = arg.transform.position.y;
        _thisPos.z = arg.transform.position.z;
        _bigExplosion.transform.position = _thisPos;
        _particle.Play();

        //倒れる
        GameObject _mubirou = GameObject.Find("mubirou");
        Animator _mubirouAnim = _mubirou.GetComponent<Animator>();
        _mubirouAnim.SetBool("isRun", false);
        _mubirouAnim.SetBool("isJump", false);
        _mubirouAnim.SetBool("isDeath", true);

        //爆発の繰返しを止める
        Invoke("BigExplosionDepth", _particle.main.duration);

        //
        _isDath = true;

        _missile = GameObject.Find("missile");
        _missileClass = _missile.GetComponent<Missile>();
        _missileClass.Enabled = false;

        //_missile.SetActive (false);
    }

    void BigExplosionDepth() {
        _particle.Stop();
        //_bigExplosion.SetActive(false);
        //
        GameObject _mubirou = GameObject.Find("mubirou");
        Animator _mubirouAnim = _mubirou.GetComponent<Animator>();
        _mubirouAnim.SetBool("isRun", true);
        _mubirouAnim.SetBool("isJump", false);
        _mubirouAnim.SetBool("isDeath", false);

        //_missile.SetActive (true);
        _missileClass.Init();
    }

    // public bool IsExplosionActive {
    //     get { return _bigExplosion.active; } //thisは省略
    //     set { _bigExplosion.SetActive(value); } //valueは決め打ち
    // }

    // void OnCollisionExit(Collision collision) {
    //     Debug.Log("B");
    // }
    
    // void OnCollisionStay(Collision collision) {
    //     Debug.Log("C");
    // }

    // //Box Collider -> Is Trigger ON
    // void OnTriggerEnter(Collider collider){
    //     Debug.Log("D");
    // }

    // void OnTriggerExit(Collider collider){
    //     Debug.Log("E");
    // }
    
    // void OnTriggerStay(Collider collider){    
    //     Debug.Log("F");
    // }
}
