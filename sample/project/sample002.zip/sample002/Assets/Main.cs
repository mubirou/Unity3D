﻿//===========================================================
// Mainクラス
//===========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro; //Text Mesh Pro用
using System; //for Math

public class Main : MonoBehaviour {
    private GameObject _missile;
    private Missile _missileScript;
    private TextMeshPro _currentScore;
    private GameObject _mubirou;
    private Mubirou _mubirouScript;
    private bool _isDeath = false;

    void Awake() {
        //フレームレートの設定
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = 24;
    }

    void Start() {
        //HIGH SCORE
        TextMeshPro _highScore = GameObject.Find("HighScore").GetComponent<TextMeshPro>();

        _highScore.text = "HIGH SCORE: " + HighScore.ToString();
		_missile = GameObject.Find("Missile");
		_missileScript = _missile.GetComponent<Missile>();
        _missileScript.AddPointEvent += PointHandler;

        //Current SCORE
        _currentScore = GameObject.Find("CurrentScore").GetComponent<TextMeshPro>();
        //Debug.Log(_currentScore.text);

        //Mubirou Event
        _mubirou = GameObject.Find("Mubirou");
        _mubirouScript = _mubirou.GetComponent<Mubirou>();
        _mubirouScript.ComebackEvent += ComebackHandler;
        _mubirouScript.DeathEvent += DeathHandler;
    }

    void Update() {
        if (_isDeath) {
            int _now = Int32.Parse(_currentScore.text.Substring(7));
            int _new = _now - 2; //減点
            _currentScore.text = "SCORE: " + _new;
        }
        
        //得点
        HighScore = Int32.Parse(_currentScore.text.Substring(7));
        //HIGH SCORE
        TextMeshPro _highScore = GameObject.Find("HighScore").GetComponent<TextMeshPro>();
        _highScore.text = "HIGH SCORE: " + HighScore.ToString();
    }

	/***************************
	Missile.PointEvent()
	***************************/
	private void PointHandler (object arg) {
        int _now = Int32.Parse(_currentScore.text.Substring(7));
        int _add = (int)GameObject.Find("Mubirou").GetComponent<Mubirou>().Point;
        int _new = _now + _add;
        _currentScore.text = "SCORE: " + _new;
    }

    void OnApplicationQuit() {
        //Debug.Log("終了");
        HighScore = Int32.Parse(_currentScore.text.Substring(7));
    }

    public int HighScore {
        get { return PlayerPrefs.GetInt("highScore"); }
        set {
            if (PlayerPrefs.GetInt("highScore") < value) {
                PlayerPrefs.SetInt("highScore", value);
            }
        }
    }

    // public int CurrentScore {
    //     get { return _currentScore.text; }
    //     set { _currentScore.text = value; }
    //     }
    // }

	private void ComebackHandler(object arg) {
		_isDeath = false;
	}

    private void DeathHandler(object arg) {
        _isDeath = true;
    }
}