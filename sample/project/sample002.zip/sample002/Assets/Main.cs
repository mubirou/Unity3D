﻿//Main.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //for Button

public class Main : MonoBehaviour {
	//private GameObject _floor;
    private GameObject _missile;
    private GameObject _mubirou;
    private Animator _mubirouAnim;

	void Start () {
        _missile = GameObject.Find("missile");

		//ボタンの色の変更
        GameObject _canvas = GameObject.Find("Canvas");
        foreach (Transform _child in _canvas.transform){
            //RUNボタンを#FFCC00に変更
            if(_child.name == "Button_Run"){
                Button _theButton = _child.gameObject.GetComponent<Button>();
                ColorBlock _colors = _theButton.colors;
                _colors.normalColor = new Color(1.0f, 0.8f, 0.0f, 1.0f);
                _theButton.colors = _colors;
            }
        }
	}
	
	void Update () {
		//_floor.transform.Rotate(new Vector3(0,1,0));

        _missile.transform.Rotate(new Vector3(0,0,-10)); //回転

        if (_missile.transform.position.z < 5) {
            Vector3 _missilePos = _missile.transform.position;
            _missilePos.z += 0.25f;
            _missile.transform.position = _missilePos;
        } else {
            //Position
            Vector3 _missilePos = _missile.transform.position;
            _missilePos.x = 0;
            _missilePos.y = 1;
            _missilePos.z = -14;
            _missile.transform.position = _missilePos;
            //Rotation??????????????????????
            Vector3 _missileAngle = _missile.transform.eulerAngles;
            _missileAngle.x = 0f;
            _missileAngle.y = 0f;
            _missileAngle.z = 0f;
            _missile.transform.eulerAngles = _missileAngle;
        }
	}
}