﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {
    private GameObject _missile;

	// Use this for initialization
	void Start () {
		_missile = GameObject.Find("missile");
	}
	
	// Update is called once per frame
	void Update () {

        _missile.transform.Rotate(new Vector3(0,0,-15)); //回転

        if (_missile.transform.position.z < 5) {
            Vector3 _missilePos = _missile.transform.position;
            _missilePos.z += 0.1f;
            _missile.transform.position = _missilePos;
        } else {
            Vector3 _missilePos = _missile.transform.position;
            _missilePos.z = -5;
            _missile.transform.position = _missilePos;
        }
	}
}
