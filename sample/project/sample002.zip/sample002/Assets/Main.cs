﻿//===========================================================
// Mainクラス
//===========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {
    void Awake() {
        //for FrameRate
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = 24;
    }
}