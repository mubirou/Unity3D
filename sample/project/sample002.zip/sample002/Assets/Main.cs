﻿//===========================================================
// Mainクラス
//===========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro; //Text Mesh Pro用
using System; //for Math

public class Main : MonoBehaviour {
    private Missile _missileScript;

    void Awake() {
        //フレームレートの設定
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = 24;
    }

    void Start() {
        //HIGH SCORE
        TextMeshPro _highScore = GameObject.Find("HighScore").GetComponent<TextMeshPro>();
        _highScore.text = "HIGH SCORE: " + HighScore.ToString();
		GameObject _theGameObject = GameObject.Find("Missile");
		_missileScript = _theGameObject.GetComponent<Missile>();
        //_missileScript.PointEvent += PointHandler;
}

	/***************************
	Missile.PointEvent()
	***************************/
	private void PointHandler (int arg) {
        Debug.Log("BBBBBBBBBBBBBBBB");
    }

    void OnApplicationQuit() {
        //Debug.Log("終了");
        HighScore = 2;
    }

    public int HighScore {
        get { return PlayerPrefs.GetInt("highScore"); }
        set {
            if (PlayerPrefs.GetInt("highScore") < value) {
                PlayerPrefs.SetInt("highScore", value);
            }
        }
    }
}