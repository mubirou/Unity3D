﻿//Main.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //for Button

public class Main : MonoBehaviour {
	//private GameObject _floor;
    private GameObject _missile;

	void Start () {
		//_floor = GameObject.Find("floor");
        _missile = GameObject.Find("missile");
        //_missile.GetComponent<Rigidbody>().useGravity = false;

		//ボタンの色の変更
        GameObject _canvas = GameObject.Find("Canvas");
        foreach (Transform _child in _canvas.transform){
            //IDLEボタンを#FFCC00に変更
            if(_child.name == "Button_Idle"){
                Button _theButton = _child.gameObject.GetComponent<Button>();
                ColorBlock _colors = _theButton.colors;
                _colors.normalColor = new Color(1.0f, 0.8f, 0.0f, 1.0f);
                _theButton.colors = _colors;
            }
        }
	}
	
	void Update () {
		//_floor.transform.Rotate(new Vector3(0,1,0));

        _missile.transform.Rotate(new Vector3(0,0,-10)); //回転

        if (_missile.transform.position.z < 5) {
            Vector3 _missilePos = _missile.transform.position;
            _missilePos.z += 0.1f;
            _missile.transform.position = _missilePos;
        } else {
            Vector3 _missilePos = _missile.transform.position;
            _missilePos.z = -5;
            _missile.transform.position = _missilePos;
        }
        
        /*
        Vector3 _missilePos = _missile.transform.position;
        _missilePos.x += 0.03f;
        _missilePos.transform.position = _missilePos;
        */

        /*
        //左→右へ移動（繰返し）
        if (_ufo.transform.position.x < 14) { //UFOが右端へ消えたら
            Vector3 _ufoPos = _ufo.transform.position;
            _ufoPos.x += 0.1f;
            _ufo.transform.position = _ufoPos;
        } else {
            InitUFO(); //初期化
        }

        if (_ufo.transform.position.y < -25) {
            InitUFO(); //初期化
        }

        if (_missile.transform.position.y < -25) {
            InitMissile(); //初期化
        }
        */
	}
}


/*
//Main.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System; //Mathに必要

public class Main : MonoBehaviour {
    private GameObject _ufo;
    private GameObject _missile;
    private GameObject _button;
    private Vector3 _originMissilePos;
    private Vector3 _originUfoPos;
    private Quaternion _originUfoQuater;
    private Quaternion _originMissileQuater;

    void Start () {
        _ufo = GameObject.Find("ufo");
        _missile = GameObject.Find("missile");
        _button = GameObject.Find("Button001");

        //デフォルトの位置の保存
        _originMissilePos = _missile.transform.position;
        _originUfoPos = _ufo.transform.position;

        //デフォルトの角度の保存
        _originUfoQuater = _ufo.transform.rotation;
        _originMissileQuater = _missile.transform.rotation;

        //初期化
        InitUFO();
        InitMissile();

        //ミサイルを落下させないようにする
        _missile.GetComponent<Rigidbody>().useGravity = false;
    }

    void Update () {
        //回転
        _ufo.transform.Rotate(new Vector3(0,0,-10));
        _missile.transform.Rotate(new Vector3(0,0,-10));

        //左→右へ移動（繰返し）
        if (_ufo.transform.position.x < 14) { //UFOが右端へ消えたら
            Vector3 _ufoPos = _ufo.transform.position;
            _ufoPos.x += 0.1f;
            _ufo.transform.position = _ufoPos;
        } else {
            InitUFO(); //初期化
        }

        if (_ufo.transform.position.y < -25) {
            InitUFO(); //初期化
        }

        if (_missile.transform.position.y < -25) {
            InitMissile(); //初期化
        }
    }

    private void InitUFO() {
        //物理処理を削除
        Rigidbody _ufoRigidbody = _ufo.GetComponent<Rigidbody>();
        _ufoRigidbody.useGravity = false;

        //動いてる物体を完全に止める
        _ufoRigidbody.velocity = Vector3.zero;
        _ufoRigidbody.angularVelocity = Vector3.zero;

        //角度を元に戻す
        _ufo.transform.rotation = _originUfoQuater;

        //画面の左端に移動
        _ufo.transform.position = _originUfoPos;
    }

    private void InitMissile() {
        //物理処理を削除
        Rigidbody _missileRigidbody = _missile.GetComponent<Rigidbody>();
        _missileRigidbody.useGravity = false;

        //画面の手前に移動
        _missile.transform.position = _originMissilePos;

        //角度を元に戻す
        _missile.transform.rotation = _originMissileQuater;

        //動いてる物体を完全に止める
        _missileRigidbody.velocity = Vector3.zero;
        _missileRigidbody.angularVelocity = Vector3.zero;

        //他のオブジェクトのメソッドを実行（ボタンの有効化）
        _button.GetComponent<MissileButton>().Show();
    }

    public void Shoot() {
        //ミサイルの物理エンジンを有効にする
        _missile.GetComponent<Rigidbody>().useGravity = true;

        //ミサイル発射（Vector3(右,上,前)）
        _missile.GetComponent<Rigidbody>().velocity = new Vector3(0,10,10);

        //ミサイルに力を加える（ミサイル発射の代替）
        //_missile.GetComponent<Rigidbody>().AddForce(0,500,500);
    }
}
*/