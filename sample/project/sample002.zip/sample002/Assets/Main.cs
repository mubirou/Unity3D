﻿/*
//Main.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //for Button
using TMPro; //for TextMeshPro
using System; //for Math

public class Main : MonoBehaviour {
    private GameObject _missile;
    private GameObject _mubirou;
    private Animator _mubirouAnim;
    private float _speed = 0.5f;

    private GameObject _missle;
    private Missile _missileClass;

    //FPS
    // private TMPro.TextMeshPro _textFPS;
    // private float m_updateInterval = 0.5f;
    // private float m_accum;
    // private int m_frames;
    // private float m_timeleft;
    // private float m_fps;

    void Awake() {
        //FPS
        QualitySettings.vSyncCount = 0; //vSyncCound is OFF
        Application.targetFrameRate = 24; //24FPS
    }

	void Start () {
        _missile = GameObject.Find("missile");

		//change color button
        GameObject _canvas = GameObject.Find("Canvas");
        foreach (Transform _child in _canvas.transform){
            //RUN button -> #FFCC00
            if(_child.name == "Button_Run"){
                Button _theButton = _child.gameObject.GetComponent<Button>();
                ColorBlock _colors = _theButton.colors;
                _colors.normalColor = new Color(1.0f, 0.8f, 0.0f, 1.0f);
                _theButton.colors = _colors;
            }
        }
        
        //FPS
        //_textFPS = GameObject.Find("textFPS").GetComponent<TextMeshPro>();

        _missle = GameObject.Find("missile");
        _missileClass = _missle.GetComponent<Missile>();
	}
	
	void Update () {
        if (_missileClass.Enabled) {
            _missile.transform.Rotate(new Vector3(0,0,-15)); //回転

            if (_missile.transform.position.z < 6.7) {
                Vector3 _missilePos = _missile.transform.position;
                _missilePos.z += _speed;
                _missile.transform.position = _missilePos;
            } else {
                _missileClass.Init();
                // Vector3 _missilePos = _missile.transform.position;
                // _missilePos.x = 0;
                // _missilePos.y = UnityEngine.Random.Range(0.5f, 2.3f); //乱数

                // _missilePos.z = -14;
                // _missile.transform.position = _missilePos;

                // _missile.transform.rotation = Quaternion.Euler(0.0f, 0.0f, 0.0f);
                // _missile.transform.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
                // _missile.transform.GetComponent<Rigidbody>().velocity = Vector3.zero;

                _speed = UnityEngine.Random.Range(0.35f, 0.5f);
            }
        }

        //FPS
        // m_timeleft -= Time.deltaTime;
        // m_accum += Time.timeScale / Time.deltaTime;
        // m_frames++;
        // if ( 0 < m_timeleft ) return;
        // m_fps = m_accum / m_frames;
        // m_timeleft = m_updateInterval;
        // m_accum = 0;
        // m_frames = 0;
        // _textFPS.text = Math.Round(m_fps).ToString() + " fps";
	}
}
*/