﻿//===========================================================
// JumpButtonクラス
//===========================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //???

public class JumpButton : MonoBehaviour {
    private Mubirou _mubirou;
    //private bool _enabled = true;
    private Button _button;

    /***************************
    JumpButton.Start()
    ***************************/
    void Start () {
        GameObject _theGameObject = GameObject.Find("Mubirou");
        _mubirou = _theGameObject.GetComponent<Mubirou>();
        _button = GetComponent<Button>();
    }

    /***************************
    JumpButton.OnClick()
    ***************************/
    public void OnClick() {
        _mubirou.Jump();
    }

    public bool Enabled {
        get { return _button.interactable; }
        set { _button.interactable = value; }
    }
}