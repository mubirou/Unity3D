﻿//JumpButton.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //for Button
using System; //for Math

public class JumpButton : MonoBehaviour {
	private GameObject _mubirou;
    private Animator _mubirouAnim;
    //for Jump
    private float _originX;
    private float _originY;
    private float _originZ;

    private float _currentX;
    private float _currentY;
    private float _currentZ;

    private float _count = 0f;
    private bool _isJump = false;
    private float _addCount = (float)Math.PI / 20;

    void Start () {
        _mubirou = GameObject.Find("mubirou");
        _mubirouAnim = _mubirou.GetComponent<Animator>();
        //for Jump
        _originX = _currentX = _mubirou.transform.position.x;
        _originY = _currentY = _mubirou.transform.position.y;
        _originZ = _currentZ = _mubirou.transform.position.z;
    }
    
    public void OnClick() {
        //for Jump
        _isJump = true;
        _mubirouAnim.SetBool("isRun", false);
        _mubirouAnim.SetBool("isWalk", false);
        _mubirouAnim.SetBool("isJump", true);
    }

    void Update () {
        if (_isJump) {
            if (_count < Math.PI) { //0-180d
                _count += _addCount; //0.2f;
                float _nextY = (float)(3 * Math.Abs(Math.Sin(_count)) + _originY);
                float _disY = _nextY - _currentY;
                _mubirou.transform.Translate(0, _disY, 0); //移動させたい値（x,y,z）を指定
                _currentY = _mubirou.transform.position.y;
            } else {
                _isJump = false;
                _count = 0f;
                _mubirouAnim.SetBool("isJump", false);
                _mubirouAnim.SetBool("isRun", true);
            }
        }
    }
}