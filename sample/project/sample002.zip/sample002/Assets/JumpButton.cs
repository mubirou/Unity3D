﻿//JumpButton.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //for Button

public class JumpButton : MonoBehaviour {
	private GameObject _mubirou;
    private Animator _mubirouAnim;

    void Start () {
        _mubirou = GameObject.Find("mubirou");
        _mubirouAnim = _mubirou.GetComponent<Animator>();
    }
    
    public void OnClick() {
        //_mubirouAnim.SetBool("isIdle", false);
		Debug.Log(_mubirou);

        switch (this.name) {
            case "Button_Idle": _mubirouAnim.SetBool("isIdle", true); break;
            default: break;
        }
    }
}