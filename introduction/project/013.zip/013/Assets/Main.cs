﻿//Main.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {
	private GameObject _piece1;
	private UnityEngine.Camera _mainCamera;

	void Start () {
		_piece1 = GameObject.Find("piece1");
		_mainCamera = Camera.main.GetComponent<Camera>();
	}

	void Update () {
		//マウスの位置を取得し、スクリーン座標→ワールド座標に変換
		Vector3 _mousePos = Input.mousePosition;
		_mousePos.z = 30f; //マウスの位置をカメラから遠ざける
		Vector3 _mouseWoldPos = _mainCamera.ScreenToWorldPoint(_mousePos);
		_piece1.transform.position = _mouseWoldPos;
	}
}