﻿//Main.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {
	private GameObject _piece1;
	private GameObject _piece2;
	private UnityEngine.Camera _mainCamera;

	void Start () {
		_piece1 = GameObject.Find("piece1");
		_mainCamera = Camera.main.GetComponent<Camera>();

		_piece2 = Instantiate(
			_piece1,
			_piece1.transform.position,
			_piece1.transform.rotation
		);
	}

	void Update () {
		//マウスの位置を取得し、スクリーン座標→ワールド座標に変換
		Vector3 _mousePos = Input.mousePosition;
		_mousePos.z = 30f; //マウスの位置をカメラから遠ざける
		Vector3 _mouseWoldPos = _mainCamera.ScreenToWorldPoint(_mousePos);
		_piece1.transform.position = _mouseWoldPos;

		float _disX = _piece1.transform.position.x - _piece2.transform.position.x;
		float _disY = _piece1.transform.position.y - _piece2.transform.position.y;
		float _disZ = _piece1.transform.position.z - _piece2.transform.position.z;

		Vector3 _addPoint = new Vector3(_disX/5, _disY/5, _disZ/5+0.4f);
		_piece2.transform.Translate(_addPoint);
	}
}