﻿//Main.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {
	private GameObject _piece0;
	//private GameObject _piece2;
	private UnityEngine.Camera _mainCamera;
	private List<GameObject> _pieceList; //動的配列の宣言
	private uint _pieceNum = 50;

	void Start () {
		_piece0 = GameObject.Find("piece");
		_mainCamera = Camera.main.GetComponent<Camera>();

		_pieceList = new List<GameObject>(); //空の動的配列の作成

		_pieceList.Add(_piece0); //先頭のpieceを動的配列に格納
        // foreach (GameObject value in _pieceList) {
        //     Debug.Log(value); //piece
        // }

		//2つ目以降のpieceを動的配列に格納
		for (int i=1; i<=_pieceNum; i++) { //iはfor文内のみ有効（1,2,...,_pieceNum）
			GameObject _thePiece = Instantiate(
				_piece0,
				_piece0.transform.position,
				_piece0.transform.rotation
			);
			_pieceList.Add(_thePiece);
        }
	}

	void Update () {
		//マウスの位置を取得し、スクリーン座標→ワールド座標に変換
		Vector3 _mousePos = Input.mousePosition;
		_mousePos.z = 30f; //マウスの位置をカメラから遠ざける
		Vector3 _mouseWoldPos = _mainCamera.ScreenToWorldPoint(_mousePos);
		_piece0.transform.position = _mouseWoldPos;

		for (int i=1; i<=_pieceNum; i++) { //iはfor文内のみ有効（1,2,...,_pieceNum）
			GameObject _thePiece = _pieceList[i];
			GameObject _frontPiece = _pieceList[i-1];
			
			float _disX = _frontPiece.transform.position.x - _thePiece.transform.position.x;
			float _disY = _frontPiece.transform.position.y - _thePiece.transform.position.y;
			float _disZ = _frontPiece.transform.position.z - _thePiece.transform.position.z;

			Vector3 _addPoint = new Vector3(_disX/4, _disY/4, _disZ/5+0.4f);_thePiece.transform.Translate(_addPoint);
        }
	}
}


// //Main.cs
// public class Main : MonoBehaviour {
// 	private GameObject _piece1;
// 	private GameObject _piece2;
// 	private UnityEngine.Camera _mainCamera;

// 	void Start () {
// 		_piece1 = GameObject.Find("piece1");
// 		_mainCamera = Camera.main.GetComponent<Camera>();

// 		_piece2 = Instantiate(
// 			_piece1,
// 			_piece1.transform.position,
// 			_piece1.transform.rotation
// 		);
// 	}

// 	void Update () {
// 		//マウスの位置を取得し、スクリーン座標→ワールド座標に変換
// 		Vector3 _mousePos = Input.mousePosition;
// 		_mousePos.z = 30f; //マウスの位置をカメラから遠ざける
// 		Vector3 _mouseWoldPos = _mainCamera.ScreenToWorldPoint(_mousePos);
// 		_piece1.transform.position = _mouseWoldPos;

// 		float _disX = _piece1.transform.position.x - _piece2.transform.position.x;
// 		float _disY = _piece1.transform.position.y - _piece2.transform.position.y;
// 		float _disZ = _piece1.transform.position.z - _piece2.transform.position.z;

// 		Vector3 _addPoint = new Vector3(_disX/5, _disY/5, _disZ/5+0.4f);
// 		_piece2.transform.Translate(_addPoint);
// 	}
// }



/*
enterframe_canvas = (_canvas) => {
	for (let i=1; i<_bitmapArray.length; i++) {
		let _theBitmap = _bitmapArray[i];
		let _leftBitmap = _bitmapArray[i - 1];
		_theBitmap.x += (_leftBitmap.x + 2 - _theBitmap.x) / 5;
		_theBitmap.y += (_leftBitmap.y - _theBitmap.y) / 5;

		let _disX = _leftBitmap.x - _theBitmap.x;
		let _disY = _leftBitmap.y - _theBitmap.y;
		let _radian = Math.atan2(_disY, _disX);
		_theBitmap.rotateRadian = _radian + Math.PI;
	}

	_canvas.drawScreen();
}
*/