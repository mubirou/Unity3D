﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ClearButton : MonoBehaviour {
	private Text _textMessage;
	private GameObject _startStopButton;

	void Start () {
		_textMessage = GameObject.Find("TextMessage").GetComponentInChildren<Text>();
		_startStopButton = GameObject.Find("StartStopButton");
	}

	public void OnClick() {
		//他のGameObjectにアタッチされたclassのメソッドを実行
		_startStopButton.GetComponent<StartStopButton>().ResetTime();
		_textMessage.text = "00:00:000";
	}

	public void Show() { //カスタムメソッド（外部からアクセス）
		this.GetComponent<Button>().interactable = true;
	}

	public void Hide() { //カスタムメソッド（外部からアクセス）
		this.GetComponent<Button>().interactable = false;
	}
}