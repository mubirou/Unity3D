﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ClearButton : MonoBehaviour {
	private GameObject _textMessage;
	private GameObject _startStopButton;

	// Use this for initialization
	void Start () {
		_textMessage = GameObject.Find("TextMessage");
		_startStopButton = GameObject.Find("StartStopButton");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnClick() { //この1行を追加
		// foreach(Transform _child in _startStopButton.transform) {
		//   if(_child.name == "Text") {

		// 	  _child.GetComponent<Text>().text = "STOP";
		//   }
		// }
	}
}
