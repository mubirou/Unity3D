﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClearButton : MonoBehaviour {
	private GameObject _textMessage;
	private GameObject _startStopButton;

	// Use this for initialization
	void Start () {
		_textMessage = GameObject.Find("TextMessage");
		_startStopButton = GameObject.Find("StartStopButton");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnClick() { //この1行を追加
		Debug.Log(_textMessage);
		Debug.Log(_startStopButton);
	}
}
