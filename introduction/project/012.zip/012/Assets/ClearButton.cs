﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ClearButton : MonoBehaviour {
	private Text _textMessage;
	private GameObject _startStopButton;

	// Use this for initialization
	void Start () {
		_textMessage = GameObject.Find("TextMessage").GetComponentInChildren<Text>();
		_startStopButton = GameObject.Find("StartStopButton");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnClick() { //この1行を追加
		_startStopButton.GetComponent<StartStopButton>().ResetTime();
		_textMessage.text = "00:00:000";
	}
}
