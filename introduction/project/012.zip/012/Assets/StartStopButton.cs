﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //Textに必要
using System; //DateTimeに必要


public class StartStopButton : MonoBehaviour {
	//private GameObject _textMessage;
	private Text _textMessage;
	private GameObject _clearButton;
	private long _start;

	// Use this for initialization
	void Start () {
		_textMessage = GameObject.Find("TextMessage").GetComponentInChildren<Text>();
		_clearButton = GameObject.Find("ClearButton");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnClick() {
		foreach(Transform _child in this.transform) {
			if(_child.name == "Text") {

				if (_child.GetComponent<Text>().text == "START") {
					_start = DateTime.Now.Ticks; //100ナノ秒単位（精度は10ミリ秒）
					_child.GetComponent<Text>().text = "STOP";

				} else if (_child.GetComponent<Text>().text == "STOP") {
					//経過時間（100ナノ秒単位）
					long _time = DateTime.Now.Ticks - _start; //最大（35999990000まで＝59分59秒999）
					//_time = 35999990000;
					Debug.Log(_time);

					//ミリ秒（000〜999）を取得
					float _tmp = _time/1000;
					long _tmpLong = (long)(Math.Round(_tmp/10) % 1000);
					string _millisec;
					if (_tmpLong < 10) {
						_millisec = "00" + _tmpLong.ToString();
					} else if (_tmpLong < 100) {
						_millisec = "0" + _tmpLong.ToString();
					} else {
						_millisec = _tmpLong.ToString();
					}

					//秒（0〜59）を取得
					_tmp = _time/100000;
					_tmpLong = (long)(Math.Floor(_tmp/100) % 60);
					string _second;
					if (_tmpLong < 10) {
						_second = "0" + _tmpLong.ToString();
					} else {
						_second = _tmpLong.ToString();
					}

					//分（0〜59）を取得
					_tmp = _time/10000000;
					_tmpLong = (long)(Math.Floor(_tmp/60));
					if (60 <= _tmpLong) _tmpLong %= 60;
					string _minute;
					if (_tmpLong < 10) {
						_minute = "0" + _tmpLong.ToString();
					} else {
						_minute = _tmpLong.ToString();
					}

					_textMessage.text = _minute + ":" + _second + ":" + _millisec;

					_child.GetComponent<Text>().text = "START";
				}
			}
		}
	}
}