﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartStopButton : MonoBehaviour {
	private GameObject _textMessage;
	private GameObject _clearButton;

	// Use this for initialization
	void Start () {
		_textMessage = GameObject.Find("TextMessage");
		_clearButton = GameObject.Find("ClearButton");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnClick() { //この1行を追加
		Debug.Log(_textMessage);
		Debug.Log(_clearButton);
	}
}
