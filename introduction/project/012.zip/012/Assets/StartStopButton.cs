﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StartStopButton : MonoBehaviour {
	private GameObject _textMessage;
	private GameObject _clearButton;

	// Use this for initialization
	void Start () {
		_textMessage = GameObject.Find("TextMessage");
		_clearButton = GameObject.Find("ClearButton");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnClick() {
		Debug.Log(_textMessage);
		Debug.Log(_clearButton.name); //"ClearButton"
		//Debug.Log(_clearButton.GetComponent<Text>()); //Null

		foreach(Transform _child in this.transform) {
			if(_child.name == "Text") {
				if (_child.GetComponent<Text>().text == "START") {
					_child.GetComponent<Text>().text = "STOP";
				} else if (_child.GetComponent<Text>().text == "STOP") {
					_child.GetComponent<Text>().text = "START";
				}
			}
		}
	}
}
