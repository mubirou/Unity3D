﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //Textに必要
using System; //DateTimeに必要


public class StartStopButton : MonoBehaviour {
	private Text _textMessage;
	private GameObject _clearButton;
	private long _startTime;
	private bool _isStart = false;
	private long _currentTime;
	private long _lapTime = 0;

	// Use this for initialization
	void Start () {
		_textMessage = GameObject.Find("TextMessage").GetComponentInChildren<Text>();
		_clearButton = GameObject.Find("ClearButton");
	}
	
	// Update is called once per frame
	void Update () {
		if (_isStart) {
			//経過時間（100ナノ秒単位）最大35999990000まで=約60分
			_currentTime = _lapTime + DateTime.Now.Ticks - _startTime; 

			//ミリ秒（000〜999）を取得
			float _tmp = _currentTime/1000;
			long _tmpLong = (long)(Math.Round(_tmp/10) % 1000);
			string _millisec;
			if (_tmpLong < 10) {
				_millisec = "00" + _tmpLong.ToString();
			} else if (_tmpLong < 100) {
				_millisec = "0" + _tmpLong.ToString();
			} else {
				_millisec = _tmpLong.ToString();
			}

			//秒（0〜59）を取得
			_tmp = _currentTime/100000;
			_tmpLong = (long)(Math.Floor(_tmp/100) % 60);
			string _second;
			if (_tmpLong < 10) {
				_second = "0" + _tmpLong.ToString();
			} else {
				_second = _tmpLong.ToString();
			}

			//分（0〜59）を取得
			_tmp = _currentTime/10000000;
			_tmpLong = (long)(Math.Floor(_tmp/60));
			if (60 <= _tmpLong) _tmpLong %= 60;
			string _minute;
			if (_tmpLong < 10) {
				_minute = "0" + _tmpLong.ToString();
			} else {
				_minute = _tmpLong.ToString();
			}

			_textMessage.text = _minute + ":" + _second + ":" + _millisec;
		}
	}

	public void OnClick() {
		foreach(Transform _child in this.transform) {
			if(_child.name == "Text") {
				if (_child.GetComponent<Text>().text == "START") {
					_startTime = DateTime.Now.Ticks; //100ナノ秒単位
					_child.GetComponent<Text>().text = "STOP";
					_isStart = true;
					//他のGameObjectにアタッチされたclassのメソッドを実行
					_clearButton.GetComponent<ClearButton>().Hide();

				} else if (_child.GetComponent<Text>().text == "STOP") {
					_child.GetComponent<Text>().text = "START";
					_isStart = false;
					_lapTime = _currentTime;
					//他のGameObjectにアタッチされたclassのメソッドを実行
					_clearButton.GetComponent<ClearButton>().Show();
				}
			}
		}
	}

	public void ResetTime() { //外部からアクセス
		_lapTime = 0;
	}
}