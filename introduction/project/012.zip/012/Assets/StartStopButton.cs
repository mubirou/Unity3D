﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //Textに必要
using System; //DateTimeに必要


public class StartStopButton : MonoBehaviour {
	//private GameObject _textMessage;
	private Text _textMessage;
	private GameObject _clearButton;
	private long _start;

	// Use this for initialization
	void Start () {
		_textMessage = GameObject.Find("TextMessage").GetComponentInChildren<Text>();
		_clearButton = GameObject.Find("ClearButton");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnClick() {
		foreach(Transform _child in this.transform) {
			if(_child.name == "Text") {

				if (_child.GetComponent<Text>().text == "START") {
					_start = DateTime.Now.Ticks; //100ナノ秒単位（精度は10ミリ秒）
					_child.GetComponent<Text>().text = "STOP";

				} else if (_child.GetComponent<Text>().text == "STOP") {
					//経過時間（100ナノ秒単位）
					long _time = DateTime.Now.Ticks - _start;
					Debug.Log(_time);

					//小数点以下を取得（1000分の1計測の場合）
					float _tmp = _time/100;
					string _num3 = (Math.Round(_tmp/100) % 1000).ToString();
					Debug.Log(_num3);

					//小数点以下を取得（100分の1計測の場合）
					// float _tmp = _time/1000;
					// string _num3 = (Math.Round(_tmp/100) % 100).ToString();
					// Debug.Log(_num3);

					_textMessage.text = "00:00:" + _num3;

					_child.GetComponent<Text>().text = "START";
				}
			}
		}
	}
}


/*
//Main.cs
using UnityEngine;
using System; //DateTimeに必要

public class Main : MonoBehaviour {
    void Start () {
        long _start = DateTime.Now.Ticks; //100ナノ秒単位（精度は10ミリ秒）
        for (long i=0; i<1000000000; i++) { //10億回繰り返す場合…
            //速度計測したい処理
        }
        Debug.Log(DateTime.Now.Ticks - _start); //19560350（≒2秒）
    }
}
*/