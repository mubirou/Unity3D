﻿//AccelerometerController.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AccelerometerController : MonoBehaviour {
	const float _gravity = 9.81f * 3; //重力加速度度（微調整）
	
	void Update () {
		Vector3 _vector = new Vector3(); //重力ベクトルの初期化

		_vector.x = Input.acceleration.x;
		_vector.z = Input.acceleration.y;
		_vector.y = Input.acceleration.z;

		Physics.gravity = _gravity * _vector.normalized;
	}
}