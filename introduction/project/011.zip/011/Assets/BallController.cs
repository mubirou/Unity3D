﻿//BallController.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallController : MonoBehaviour {
	private GameObject _ball; //ターゲットのGameObjectの参照
	private float _originX;
	private float _originY;
	private float _originZ;

	void Start () {
		_ball = GameObject.Find("Ball"); //シーンの中から任意のGameObjectを探す
		_originX = _ball.transform.position.x;
		_originY = _ball.transform.position.y;
		_originZ = _ball.transform.position.z;
	}
	
	void Update () {
		if (_ball.transform.position.y < -1) {
			Vector3 _pos = _ball.transform.position;
			_pos.x = _originX;
			_pos.y = _originY;
			_pos.z = _originZ;
			_ball.transform.position = _pos;
		}
	}
}