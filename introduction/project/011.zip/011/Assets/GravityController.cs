﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GravityController : MonoBehaviour {
	const float _gravity = 9.81f * 10; //①重力加速度度（10倍にしてみる）
	public float _gravityScale = 1.0f; //②重力のスケールパラメータ

	// Use this for initialization
	void Start () {
		//Debug.Log("Hello,world!");
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 _vector = new Vector3(); //③重力ベクトルの初期化
		 
		if (Application.isEditor) { //Unityエディタの場合
			_vector.x = Input.GetAxis("Horizontal");
			_vector.y = Input.GetAxis("Vertical");

			if (Input.GetKey("z")) {
				_vector.y = 1.0f;
			} else {
				_vector.y = -1.0f;
			}
		} else { //実機の場合
			_vector.x = Input.acceleration.x;
			_vector.z = Input.acceleration.y;
			_vector.y = Input.acceleration.z;
		}

		Physics.gravity = _gravity * _vector.normalized * _gravityScale;
	}
}
