﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeAll : MonoBehaviour {
	private Animator _animator;

	void Start () {
		_animator = this.GetComponent<Animator>();
		Debug.Log(_animator);
	}
	
	void Update () {
	}
}