﻿//MissileButton.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MissileButton : MonoBehaviour {
    private GameObject _god;
    private GameObject _ufo;

    void Start () {
        _god = GameObject.Find("God");
        _ufo = GameObject.Find("ufo");
    }

    public void OnClick() {
        _god.SendMessage("Shoot");
        
        //他のオブジェクトのメソッドを実行（ボタンの無効化）
        GetComponent<MissileButton>().Hide();

        //爆発の有効化
        _ufo.GetComponent<Ufo>().IsExplosionActive = true;
    }

    public void Show() { //カスタムメソッド（外部からアクセス）
        this.GetComponent<Button>().interactable = true;
    }

    public void Hide() { //カスタムメソッド（外部からアクセス）
        this.GetComponent<Button>().interactable = false;
    }
}