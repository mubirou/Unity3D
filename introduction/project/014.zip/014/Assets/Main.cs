﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {
	private GameObject _ufo;
	private GameObject _missile;

	void Start () {
		_ufo = GameObject.Find("ufo");
		_missile = GameObject.Find("missile");

		//初期化
		InitUFO();
		InitMissile();

		//ミサイルに力を加える
		//_missile.GetComponent<Rigidbody>().AddForce(0,500,500);

		//ミサイル発射
		_missile.GetComponent<Rigidbody>().velocity = new Vector3(0,10,10); //右,上,前
	}

	void Update () {
		//回転
		_ufo.transform.Rotate(new Vector3(0,-10,0));
		_missile.transform.Rotate(new Vector3(0,0,-10));

		//左→右へ移動（繰返し）
		if (_ufo.transform.position.x < 14) { //UFOが右端へ消えたら...
			Vector3 _ufoPos = _ufo.transform.position;
			_ufoPos.x += 0.1f;
			_ufo.transform.position = _ufoPos;
		} else {
			InitUFO(); //初期化
		}
	}

	private void InitUFO() {
		//画面の左端に移動
		Vector3 _ufoPos = _ufo.transform.position;
		_ufoPos.x = -14;
		_ufoPos.y = 3;
		_ufoPos.z = 3;
		_ufo.transform.position = _ufoPos;
	}

	private void InitMissile() {
		//画面の手前に移動
		Vector3 _missilePos = _missile.transform.position;
		_missilePos.y = -1.2f;
		_missilePos.z = -7;
		_missile.transform.position = _missilePos;
	}
}
