﻿//Ufo.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ufo : MonoBehaviour {
    private GameObject _bigExplosion;
    private ParticleSystem _particle;

    void Start () {
        GetComponent<Rigidbody>().useGravity = false;
        _bigExplosion = GameObject.Find("BigExplosion");
        _particle =_bigExplosion.GetComponent<ParticleSystem>();
        _particle.Stop();
    }

    void OnCollisionEnter(Collision arg) { //衝突判定
        GetComponent<Rigidbody>().useGravity = true; //落下

        //パーティクル再生（爆発）
        Vector3 _thisPos = _bigExplosion.transform.position;
        _thisPos.x = arg.transform.position.x;
        _thisPos.y = arg.transform.position.y;
        _bigExplosion.transform.position = _thisPos;
        _particle.Play();

        //爆発の繰返しを止める
        Invoke("BigExplosionDepth", _particle.main.duration);
    }
    
    void BigExplosionDepth() {
        _particle.Stop();
        _bigExplosion.SetActive(false);
    }

    public bool IsExplosionActive {
        get { return _bigExplosion.active; } //thisは省略
        set { _bigExplosion.SetActive(value); } //valueは決め打ち
    }
}