﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ufo : MonoBehaviour {

	// Use this for initialization
	void Start () {
		GetComponent<Rigidbody>().useGravity = false;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision arg) { //衝突判定（当たり判定）イベント
		GetComponent<Rigidbody>().useGravity = true;
	}

}
