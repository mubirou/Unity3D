﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables; //PlayableDirectorに必要

public class CubeAll : MonoBehaviour {
	private GameObject _cubeAll;
	private PlayableDirector _playable;

	void Start () {
		_cubeAll = GameObject.Find("CubeAll");
		_playable = _cubeAll.GetComponent<PlayableDirector>();
		//Debug.Log(_playable.duration); //1.400000005959（秒）←総フレーム数/フレームレート
	}
	
	void Update () {
		//Debug.Log(_playable.time);
	}
}