﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {
	private GameObject _boy;
	private CharacterController _boyController;

	// Use this for initialization
	void Start () {
		_boy = GameObject.Find("boy");
		_boyController = _boy.GetComponent<CharacterController>();
		Debug.Log(_boyController);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
