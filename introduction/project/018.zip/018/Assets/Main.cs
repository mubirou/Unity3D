﻿//Main.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {
	private GameObject _floor;

	void Start () {
		_floor = GameObject.Find("floor");
	}
	
	void Update () {
		_floor.transform.Rotate(new Vector3(0,1,0));
	}
}
