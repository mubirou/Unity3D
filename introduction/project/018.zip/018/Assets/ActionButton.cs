﻿//ActionButton.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //for Button

public class ActionButton : MonoBehaviour {
	private GameObject _mubirou;
    private Animator _mubirouAnim;

    void Start () {
        _mubirou = GameObject.Find("mubirou");
        _mubirouAnim = _mubirou.GetComponent<Animator>();
    }
    
    public void OnClick() {
        _mubirouAnim.SetBool("isIdle", false);
        _mubirouAnim.SetBool("isFly", false);
        _mubirouAnim.SetBool("isJump", false);
        _mubirouAnim.SetBool("isRun", false);
        _mubirouAnim.SetBool("isWalk", false);
        _mubirouAnim.SetBool("isRove", false);
        _mubirouAnim.SetBool("isDeath", false);
        _mubirouAnim.SetBool("isBreak", false);
        _mubirouAnim.SetBool("isAttack", false);

        switch (this.name) {
            case "Button_IDLE": _mubirouAnim.SetBool("isIdle", true); break;
            case "Button_ROVE": _mubirouAnim.SetBool("isRove", true); break;
            case "Button_WALK": _mubirouAnim.SetBool("isWalk", true); break;
            case "Button_RUN": _mubirouAnim.SetBool("isRun", true); break;
            case "Button_JUMP": _mubirouAnim.SetBool("isJump", true); break;
            case "Button_FLY": _mubirouAnim.SetBool("isFly", true); break;
            case "Button_ATTACK": _mubirouAnim.SetBool("isAttack", true); break;
            case "Button_BREAK": _mubirouAnim.SetBool("isBreak", true); break;
            case "Button_DEATH": _mubirouAnim.SetBool("isDeath", true); break;
            default: break;
        }

        var _colors = this.GetComponent<Button>().colors;
        _colors.highlightedColor = new Color(1.0f, 0.8f, 0.0f, 1.0f);
        this.GetComponent<Button>().colors = _colors;
    }
}