﻿//JumpButton.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpButton : MonoBehaviour {
	private GameObject _mubirou;
    private Animator _mubirouAnim;

    void Start () {
        _mubirou = GameObject.Find("mubirou");
        _mubirouAnim = _mubirou.GetComponent<Animator>();
    }
    
    public void OnClick() {
        _mubirouAnim.SetBool("isIdle", false);
        _mubirouAnim.SetBool("isFly", false);
        _mubirouAnim.SetBool("isJump", true);
        _mubirouAnim.SetBool("isRun", false);
        _mubirouAnim.SetBool("isWalk", false);
        _mubirouAnim.SetBool("isRove", false);
        _mubirouAnim.SetBool("isDeath", false);
        _mubirouAnim.SetBool("isBreak", false);
        _mubirouAnim.SetBool("isAttack", false);
    }
}