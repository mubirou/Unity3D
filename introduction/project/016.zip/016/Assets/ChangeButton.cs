﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeButton : MonoBehaviour {
	private GameObject _robot;

	// Use this for initialization
	void Start () {
		_robot = GameObject.Find("robot");
	}
	
    public void OnClick() {
			Debug.Log(_robot);
    }
}
