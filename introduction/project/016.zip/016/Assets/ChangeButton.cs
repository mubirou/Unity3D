﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeButton : MonoBehaviour {
	private GameObject _robot;
	private Animator _robotAnim;

	// Use this for initialization
	void Start () {
		_robot = GameObject.Find("robot");
		_robotAnim = _robot.GetComponent<Animator>();

		AnimatorStateInfo _robotState = _robotAnim.GetCurrentAnimatorStateInfo(0);
		//Debug.Log(_robotState);
	}
	
    public void OnClick() {
		//_robotAnim.speed = 0; //その状態で止まる
    }
}