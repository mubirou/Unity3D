﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RunButton : MonoBehaviour {
	private GameObject _robot;
	private Animator _robotAnim;

	void Start () {
		_robot = GameObject.Find("robot");
		_robotAnim = _robot.GetComponent<Animator>();
	}
	
    public void OnClick() {
		_robotAnim.SetBool("isWalk", false);
		_robotAnim.SetBool("isRun", true);
	}
}
	
	/*
	//private AnimatorStateInfo _robotState;
	//_robotState = _robotAnim.GetCurrentAnimatorStateInfo(0);
	//string _currentClip = _robotAnim.GetCurrentAnimatorClipInfo (0)[0].clip.name;
	if (_currentClip == "Armature|Stop") {
		_robotAnim.SetBool("isRun", true); // 再開
	} else if (_currentClip == "Armature|Walk") {
		_robotAnim.SetBool("isWalk", false);
		_robotAnim.SetBool("isRun", true);
		//_robotAnim.SetBool("isWalk_Stop", false); //ダメ
	}
	*/
	//_robotAnim.Play("Armature|Run"); //アニメーションをブレンドせずに再生
	//_robotAnim.speed = 0; //その状態で止まる
//}