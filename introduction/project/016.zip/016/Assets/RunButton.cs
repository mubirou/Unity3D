﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RunButton : MonoBehaviour {
	private GameObject _robot;
	private Animator _robotAnim;
	//private AnimatorStateInfo _robotState;

	void Start () {
		_robot = GameObject.Find("robot");
		_robotAnim = _robot.GetComponent<Animator>();
		//_robotState = _robotAnim.GetCurrentAnimatorStateInfo(0);
	}
	
    public void OnClick() {
		string _currentClip = _robotAnim.GetCurrentAnimatorClipInfo (0)[0].clip.name;
		if (_currentClip == "Armature|Stop") {
			_robotAnim.SetBool("isRun_Stop", true); // 再開
		}
		//_robotAnim.Play("Armature|Run"); //アニメーションをブレンドせずに再生
		//_robotAnim.speed = 0; //その状態で止まる
    }
}