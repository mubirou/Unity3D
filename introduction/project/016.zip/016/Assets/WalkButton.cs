﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WalkButton : MonoBehaviour {
	private GameObject _robot;
	private Animator _robotAnim;

	void Start () {
		_robot = GameObject.Find("robot");
		_robotAnim = _robot.GetComponent<Animator>();
	}
	
    public void OnClick() {
		_robotAnim.SetBool("isWalk", true);
		_robotAnim.SetBool("isRun", false);
	}
}