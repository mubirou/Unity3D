﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopButton : MonoBehaviour {
	private GameObject _robot;
	private Animator _robotAnim;
	//private AnimatorStateInfo _robotState;

	void Start () {
		_robot = GameObject.Find("robot");
		_robotAnim = _robot.GetComponent<Animator>();
		//_robotState = _robotAnim.GetCurrentAnimatorStateInfo(0);
	}
	
    public void OnClick() {
		_robotAnim.SetBool("isWalk_Stop", false);
		_robotAnim.SetBool("isRun_Stop", false);
    }
}