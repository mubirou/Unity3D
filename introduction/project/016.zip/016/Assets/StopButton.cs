﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopButton : MonoBehaviour {
	private GameObject _robot;
	private Animator _robotAnim;

	void Start () {
		_robot = GameObject.Find("robot");
		_robotAnim = _robot.GetComponent<Animator>();
	}
	
    public void OnClick() {
		_robotAnim.SetBool("isWalk", false);
		_robotAnim.SetBool("isRun", false);
    }
}

//private AnimatorStateInfo _robotState;
//_robotState = _robotAnim.GetCurrentAnimatorStateInfo(0);