﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopButton : MonoBehaviour {
	private GameObject _robot;
	private Animator _robotAnim;
	private AnimatorStateInfo _robotState;

	// Use this for initialization
	void Start () {
		_robot = GameObject.Find("robot");
		_robotAnim = _robot.GetComponent<Animator>();

		_robotState = _robotAnim.GetCurrentAnimatorStateInfo(0);
		//Debug.Log(_robotState);
	}
	
    public void OnClick() {
		Debug.Log("Stop");
		Debug.Log(_robot);
		Debug.Log(_robotAnim);
		Debug.Log(_robotState);
		//_robotAnim.speed = 0; //その状態で止まる
    }
}