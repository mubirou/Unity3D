﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopButton : MonoBehaviour {
	private GameObject _robot;
	private Animator _robotAnim;
	private AnimatorStateInfo _robotState;

	// Use this for initialization
	void Start () {
		_robot = GameObject.Find("robot");
		_robotAnim = _robot.GetComponent<Animator>();

		_robotState = _robotAnim.GetCurrentAnimatorStateInfo(0);
		//Debug.Log(_robotState);

		_robotAnim.SetFloat("MovingSpeed", 0.0f); // 一時停止
	}
	
    public void OnClick() {
		Debug.Log("Stop");
		Debug.Log(_robotAnim.GetCurrentAnimatorClipInfo (0)[0].clip.name);
		_robotAnim.Play("Armature|Stop"); //アニメーションをブレンドせずに再生
		//_robotAnim.speed = 0; //その状態で止まる

		//_robotAnim.SetFloat("MovingSpeed", 1.0f); // 再開
    }
}